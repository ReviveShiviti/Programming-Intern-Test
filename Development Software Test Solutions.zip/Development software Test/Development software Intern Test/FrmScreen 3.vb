﻿Option Explicit On
Option Strict On

Public Class frmScreen3
    Public Sub ViewData()
        
    End Sub
    Private Sub btnOK_Click(sender As Object, e As EventArgs)
        If MessageBox.Show("Do you want to go back to main menu?", "READY TO RETURN", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            MessageBox.Show("Thankyou:")
            Application.Exit()
        End If
    End Sub

    Private Sub frmScreen3_Load(sender As Object, e As EventArgs) Handles MyBase.Load


        Me.lblTotalNo.Text = "Total number of surveys"
        Me.lblAverage.Text = "Average age"
        Me.lblOldest.Text = "oldest person who participated in survey"
        Me.lblYoungest.Text = "Youngest person who participated in survey"



       

    End Sub
End Class