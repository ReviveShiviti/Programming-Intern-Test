﻿Public Class Form1
    Private Sub btnFill_Click(sender As Object, e As EventArgs) Handles btnFill.Click

        Dim btnFill As New FrmScreen_2
        btnFill.MdiParent = Me
        btnFill.Show()

    End Sub

    Private Sub btnView_Click(sender As Object, e As EventArgs) Handles btnView.Click
        Dim btnView As New frmScreen3
        btnView.MdiParent = Me
        btnFill.Show()
    End Sub
End Class
