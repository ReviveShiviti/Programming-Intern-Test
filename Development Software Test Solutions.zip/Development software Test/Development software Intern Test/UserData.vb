﻿Module UserData
    Public arSurveys As UserDetails
    Public arAge(20) As Integer
    Public arCnt As Integer = 0

    Public Pizza As Integer = 0
    Public Pasta As Integer = 0
    Public PapWors As Integer = 0
    Public ChickFr As Integer = 0
    Public BeefFr As Integer = 0
    Public Other As Integer = 0

    Public EatOut As Integer = 0
    Public WatchMovies As Integer = 0
    Public WatchTV As Integer = 0
    Public Lradio As Integer = 0


End Module
