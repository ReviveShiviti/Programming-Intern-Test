﻿Public Class FrmScreen_2

    Private Sub FrmScreen_2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub RadioButton6_CheckedChanged(sender As Object, e As EventArgs) Handles rdbAgreeM.CheckedChanged

    End Sub
End Class