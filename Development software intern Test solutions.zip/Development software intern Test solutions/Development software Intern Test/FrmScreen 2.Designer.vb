﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmScreen_2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblTake = New System.Windows.Forms.Label()
        Me.lblPersonal = New System.Windows.Forms.Label()
        Me.lblSuname = New System.Windows.Forms.Label()
        Me.label = New System.Windows.Forms.Label()
        Me.lblContact = New System.Windows.Forms.Label()
        Me.lblDate = New System.Windows.Forms.Label()
        Me.lblAge = New System.Windows.Forms.Label()
        Me.txtSurname = New System.Windows.Forms.TextBox()
        Me.txtDate = New System.Windows.Forms.TextBox()
        Me.txtContact = New System.Windows.Forms.TextBox()
        Me.txtFirst = New System.Windows.Forms.TextBox()
        Me.txtAge = New System.Windows.Forms.TextBox()
        Me.lblFavourite = New System.Windows.Forms.Label()
        Me.chkPizza = New System.Windows.Forms.CheckBox()
        Me.chkPasta = New System.Windows.Forms.CheckBox()
        Me.chkPapandWors = New System.Windows.Forms.CheckBox()
        Me.chkChicken = New System.Windows.Forms.CheckBox()
        Me.chkBeef = New System.Windows.Forms.CheckBox()
        Me.chkoOther = New System.Windows.Forms.CheckBox()
        Me.lblIndicate = New System.Windows.Forms.Label()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.rdbstrong = New System.Windows.Forms.RadioButton()
        Me.rdbMovies = New System.Windows.Forms.RadioButton()
        Me.rdbTv = New System.Windows.Forms.RadioButton()
        Me.rdbRadio = New System.Windows.Forms.RadioButton()
        Me.rdbAgree = New System.Windows.Forms.RadioButton()
        Me.rdbAgreeM = New System.Windows.Forms.RadioButton()
        Me.rdbAgreeT = New System.Windows.Forms.RadioButton()
        Me.rdbNeutralO = New System.Windows.Forms.RadioButton()
        Me.rdbNeturalR = New System.Windows.Forms.RadioButton()
        Me.rdbNeutralT = New System.Windows.Forms.RadioButton()
        Me.rdbNuetralM = New System.Windows.Forms.RadioButton()
        Me.rdbDisagO = New System.Windows.Forms.RadioButton()
        Me.rdbDisagreR = New System.Windows.Forms.RadioButton()
        Me.rdbDisagreT = New System.Windows.Forms.RadioButton()
        Me.rdbDisagreM = New System.Windows.Forms.RadioButton()
        Me.rdbStrongR = New System.Windows.Forms.RadioButton()
        Me.rdbStrongT = New System.Windows.Forms.RadioButton()
        Me.rdbStrongM = New System.Windows.Forms.RadioButton()
        Me.rdbStrongO = New System.Windows.Forms.RadioButton()
        Me.AgreeR = New System.Windows.Forms.RadioButton()
        Me.SuspendLayout()
        '
        'lblTake
        '
        Me.lblTake.AutoSize = True
        Me.lblTake.Location = New System.Drawing.Point(12, 9)
        Me.lblTake.Name = "lblTake"
        Me.lblTake.Size = New System.Drawing.Size(86, 13)
        Me.lblTake.TabIndex = 0
        Me.lblTake.Text = "Take our Survey"
        '
        'lblPersonal
        '
        Me.lblPersonal.AutoSize = True
        Me.lblPersonal.Location = New System.Drawing.Point(12, 41)
        Me.lblPersonal.Name = "lblPersonal"
        Me.lblPersonal.Size = New System.Drawing.Size(86, 13)
        Me.lblPersonal.TabIndex = 1
        Me.lblPersonal.Text = "Personal Details:"
        '
        'lblSuname
        '
        Me.lblSuname.AutoSize = True
        Me.lblSuname.Location = New System.Drawing.Point(58, 77)
        Me.lblSuname.Name = "lblSuname"
        Me.lblSuname.Size = New System.Drawing.Size(49, 13)
        Me.lblSuname.TabIndex = 2
        Me.lblSuname.Text = "Surname"
        '
        'label
        '
        Me.label.AutoSize = True
        Me.label.Location = New System.Drawing.Point(58, 99)
        Me.label.Name = "label"
        Me.label.Size = New System.Drawing.Size(62, 13)
        Me.label.TabIndex = 3
        Me.label.Text = "First Names"
        '
        'lblContact
        '
        Me.lblContact.AutoSize = True
        Me.lblContact.Location = New System.Drawing.Point(58, 123)
        Me.lblContact.Name = "lblContact"
        Me.lblContact.Size = New System.Drawing.Size(82, 13)
        Me.lblContact.TabIndex = 4
        Me.lblContact.Text = "Contact number"
        '
        'lblDate
        '
        Me.lblDate.AutoSize = True
        Me.lblDate.Location = New System.Drawing.Point(58, 147)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(30, 13)
        Me.lblDate.TabIndex = 5
        Me.lblDate.Text = "Date"
        '
        'lblAge
        '
        Me.lblAge.AutoSize = True
        Me.lblAge.Location = New System.Drawing.Point(58, 174)
        Me.lblAge.Name = "lblAge"
        Me.lblAge.Size = New System.Drawing.Size(26, 13)
        Me.lblAge.TabIndex = 6
        Me.lblAge.Text = "Age"
        '
        'txtSurname
        '
        Me.txtSurname.Location = New System.Drawing.Point(159, 74)
        Me.txtSurname.Name = "txtSurname"
        Me.txtSurname.Size = New System.Drawing.Size(199, 20)
        Me.txtSurname.TabIndex = 7
        '
        'txtDate
        '
        Me.txtDate.Location = New System.Drawing.Point(159, 151)
        Me.txtDate.Name = "txtDate"
        Me.txtDate.Size = New System.Drawing.Size(199, 20)
        Me.txtDate.TabIndex = 8
        '
        'txtContact
        '
        Me.txtContact.Location = New System.Drawing.Point(159, 125)
        Me.txtContact.Name = "txtContact"
        Me.txtContact.Size = New System.Drawing.Size(199, 20)
        Me.txtContact.TabIndex = 9
        '
        'txtFirst
        '
        Me.txtFirst.Location = New System.Drawing.Point(159, 99)
        Me.txtFirst.Name = "txtFirst"
        Me.txtFirst.Size = New System.Drawing.Size(199, 20)
        Me.txtFirst.TabIndex = 10
        '
        'txtAge
        '
        Me.txtAge.Location = New System.Drawing.Point(159, 177)
        Me.txtAge.Name = "txtAge"
        Me.txtAge.Size = New System.Drawing.Size(38, 20)
        Me.txtAge.TabIndex = 11
        '
        'lblFavourite
        '
        Me.lblFavourite.AutoSize = True
        Me.lblFavourite.Location = New System.Drawing.Point(12, 212)
        Me.lblFavourite.Name = "lblFavourite"
        Me.lblFavourite.Size = New System.Drawing.Size(320, 13)
        Me.lblFavourite.TabIndex = 12
        Me.lblFavourite.Text = "What is your favourite food?(You can choose more than 1 answer)"
        '
        'chkPizza
        '
        Me.chkPizza.AutoSize = True
        Me.chkPizza.Location = New System.Drawing.Point(17, 228)
        Me.chkPizza.Name = "chkPizza"
        Me.chkPizza.Size = New System.Drawing.Size(51, 17)
        Me.chkPizza.TabIndex = 13
        Me.chkPizza.Text = "Pizza"
        Me.chkPizza.UseVisualStyleBackColor = True
        '
        'chkPasta
        '
        Me.chkPasta.AutoSize = True
        Me.chkPasta.Location = New System.Drawing.Point(17, 243)
        Me.chkPasta.Name = "chkPasta"
        Me.chkPasta.Size = New System.Drawing.Size(53, 17)
        Me.chkPasta.TabIndex = 14
        Me.chkPasta.Text = "Pasta"
        Me.chkPasta.UseVisualStyleBackColor = True
        '
        'chkPapandWors
        '
        Me.chkPapandWors.AutoSize = True
        Me.chkPapandWors.Location = New System.Drawing.Point(17, 259)
        Me.chkPapandWors.Name = "chkPapandWors"
        Me.chkPapandWors.Size = New System.Drawing.Size(94, 17)
        Me.chkPapandWors.TabIndex = 15
        Me.chkPapandWors.Text = "Pap and Wors"
        Me.chkPapandWors.UseVisualStyleBackColor = True
        '
        'chkChicken
        '
        Me.chkChicken.AutoSize = True
        Me.chkChicken.Location = New System.Drawing.Point(17, 274)
        Me.chkChicken.Name = "chkChicken"
        Me.chkChicken.Size = New System.Drawing.Size(95, 17)
        Me.chkChicken.TabIndex = 16
        Me.chkChicken.Text = "Chicken stir fry"
        Me.chkChicken.UseVisualStyleBackColor = True
        '
        'chkBeef
        '
        Me.chkBeef.AutoSize = True
        Me.chkBeef.Location = New System.Drawing.Point(17, 290)
        Me.chkBeef.Name = "chkBeef"
        Me.chkBeef.Size = New System.Drawing.Size(78, 17)
        Me.chkBeef.TabIndex = 17
        Me.chkBeef.Text = "Beef stir fry"
        Me.chkBeef.UseVisualStyleBackColor = True
        '
        'chkoOther
        '
        Me.chkoOther.AutoSize = True
        Me.chkoOther.Location = New System.Drawing.Point(17, 306)
        Me.chkoOther.Name = "chkoOther"
        Me.chkoOther.Size = New System.Drawing.Size(52, 17)
        Me.chkoOther.TabIndex = 18
        Me.chkoOther.Text = "Other"
        Me.chkoOther.UseVisualStyleBackColor = True
        '
        'lblIndicate
        '
        Me.lblIndicate.AutoSize = True
        Me.lblIndicate.Location = New System.Drawing.Point(14, 351)
        Me.lblIndicate.Name = "lblIndicate"
        Me.lblIndicate.Size = New System.Drawing.Size(323, 13)
        Me.lblIndicate.TabIndex = 19
        Me.lblIndicate.Text = "On a scale of 1 to 5 indicate you strongly agree to strongly disagree"
        '
        'btnSubmit
        '
        Me.btnSubmit.Location = New System.Drawing.Point(351, 545)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(75, 23)
        Me.btnSubmit.TabIndex = 20
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.SystemColors.InfoText
        Me.TextBox1.Location = New System.Drawing.Point(17, 367)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(128, 86)
        Me.TextBox1.TabIndex = 21
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.SystemColors.InfoText
        Me.TextBox2.Location = New System.Drawing.Point(140, 367)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(128, 65)
        Me.TextBox2.TabIndex = 22
        '
        'TextBox3
        '
        Me.TextBox3.BackColor = System.Drawing.SystemColors.InfoText
        Me.TextBox3.Location = New System.Drawing.Point(261, 367)
        Me.TextBox3.Multiline = True
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(86, 65)
        Me.TextBox3.TabIndex = 23
        '
        'TextBox4
        '
        Me.TextBox4.BackColor = System.Drawing.SystemColors.InfoText
        Me.TextBox4.Location = New System.Drawing.Point(338, 367)
        Me.TextBox4.Multiline = True
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(98, 65)
        Me.TextBox4.TabIndex = 24
        '
        'TextBox5
        '
        Me.TextBox5.BackColor = System.Drawing.SystemColors.InfoText
        Me.TextBox5.Location = New System.Drawing.Point(429, 367)
        Me.TextBox5.Multiline = True
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(101, 77)
        Me.TextBox5.TabIndex = 25
        '
        'TextBox6
        '
        Me.TextBox6.BackColor = System.Drawing.SystemColors.InfoText
        Me.TextBox6.Location = New System.Drawing.Point(526, 367)
        Me.TextBox6.Multiline = True
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(128, 65)
        Me.TextBox6.TabIndex = 26
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(140, 429)
        Me.TextBox7.Multiline = True
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(128, 110)
        Me.TextBox7.TabIndex = 27
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(17, 427)
        Me.TextBox8.Multiline = True
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(123, 112)
        Me.TextBox8.TabIndex = 28
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(261, 429)
        Me.TextBox9.Multiline = True
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(76, 110)
        Me.TextBox9.TabIndex = 29
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(336, 429)
        Me.TextBox10.Multiline = True
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(100, 110)
        Me.TextBox10.TabIndex = 30
        '
        'TextBox11
        '
        Me.TextBox11.Location = New System.Drawing.Point(429, 427)
        Me.TextBox11.Multiline = True
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(101, 112)
        Me.TextBox11.TabIndex = 31
        '
        'TextBox12
        '
        Me.TextBox12.Location = New System.Drawing.Point(526, 427)
        Me.TextBox12.Multiline = True
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(128, 112)
        Me.TextBox12.TabIndex = 32
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(167, 390)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(88, 13)
        Me.Label1.TabIndex = 33
        Me.Label1.Text = "Strongly Agree(1)"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(274, 390)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(47, 13)
        Me.Label2.TabIndex = 34
        Me.Label2.Text = "Agree(2)"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(374, 390)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 13)
        Me.Label3.TabIndex = 35
        Me.Label3.Text = "Nuetral(3)"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(442, 390)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(61, 13)
        Me.Label4.TabIndex = 36
        Me.Label4.Text = "Disagree(4)"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(536, 390)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(102, 13)
        Me.Label5.TabIndex = 37
        Me.Label5.Text = "Strongly Disagree(5)"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(43, 432)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(77, 13)
        Me.Label6.TabIndex = 38
        Me.Label6.Text = "I like to eat out"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(25, 456)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(109, 13)
        Me.Label7.TabIndex = 39
        Me.Label7.Text = "I like to watch movies"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(43, 481)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(90, 13)
        Me.Label8.TabIndex = 40
        Me.Label8.Text = "I like to watch TV"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(16, 510)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(124, 13)
        Me.Label9.TabIndex = 41
        Me.Label9.Text = "I like to listen to the radio"
        '
        'rdbstrong
        '
        Me.rdbstrong.AutoSize = True
        Me.rdbstrong.Location = New System.Drawing.Point(193, 432)
        Me.rdbstrong.Name = "rdbstrong"
        Me.rdbstrong.Size = New System.Drawing.Size(14, 13)
        Me.rdbstrong.TabIndex = 42
        Me.rdbstrong.TabStop = True
        Me.rdbstrong.UseVisualStyleBackColor = True
        '
        'rdbMovies
        '
        Me.rdbMovies.AutoSize = True
        Me.rdbMovies.Location = New System.Drawing.Point(193, 456)
        Me.rdbMovies.Name = "rdbMovies"
        Me.rdbMovies.Size = New System.Drawing.Size(14, 13)
        Me.rdbMovies.TabIndex = 43
        Me.rdbMovies.TabStop = True
        Me.rdbMovies.UseVisualStyleBackColor = True
        '
        'rdbTv
        '
        Me.rdbTv.AutoSize = True
        Me.rdbTv.Location = New System.Drawing.Point(193, 481)
        Me.rdbTv.Name = "rdbTv"
        Me.rdbTv.Size = New System.Drawing.Size(14, 13)
        Me.rdbTv.TabIndex = 44
        Me.rdbTv.TabStop = True
        Me.rdbTv.UseVisualStyleBackColor = True
        '
        'rdbRadio
        '
        Me.rdbRadio.AutoSize = True
        Me.rdbRadio.Location = New System.Drawing.Point(193, 512)
        Me.rdbRadio.Name = "rdbRadio"
        Me.rdbRadio.Size = New System.Drawing.Size(14, 13)
        Me.rdbRadio.TabIndex = 45
        Me.rdbRadio.TabStop = True
        Me.rdbRadio.UseVisualStyleBackColor = True
        '
        'rdbAgree
        '
        Me.rdbAgree.AutoSize = True
        Me.rdbAgree.Location = New System.Drawing.Point(288, 432)
        Me.rdbAgree.Name = "rdbAgree"
        Me.rdbAgree.Size = New System.Drawing.Size(14, 13)
        Me.rdbAgree.TabIndex = 46
        Me.rdbAgree.TabStop = True
        Me.rdbAgree.UseVisualStyleBackColor = True
        '
        'rdbAgreeM
        '
        Me.rdbAgreeM.AutoSize = True
        Me.rdbAgreeM.Location = New System.Drawing.Point(288, 456)
        Me.rdbAgreeM.Name = "rdbAgreeM"
        Me.rdbAgreeM.Size = New System.Drawing.Size(14, 13)
        Me.rdbAgreeM.TabIndex = 47
        Me.rdbAgreeM.TabStop = True
        Me.rdbAgreeM.UseVisualStyleBackColor = True
        '
        'rdbAgreeT
        '
        Me.rdbAgreeT.AutoSize = True
        Me.rdbAgreeT.Location = New System.Drawing.Point(288, 481)
        Me.rdbAgreeT.Name = "rdbAgreeT"
        Me.rdbAgreeT.Size = New System.Drawing.Size(14, 13)
        Me.rdbAgreeT.TabIndex = 48
        Me.rdbAgreeT.TabStop = True
        Me.rdbAgreeT.UseVisualStyleBackColor = True
        '
        'rdbNeutralO
        '
        Me.rdbNeutralO.AutoSize = True
        Me.rdbNeutralO.Location = New System.Drawing.Point(377, 431)
        Me.rdbNeutralO.Name = "rdbNeutralO"
        Me.rdbNeutralO.Size = New System.Drawing.Size(14, 13)
        Me.rdbNeutralO.TabIndex = 49
        Me.rdbNeutralO.TabStop = True
        Me.rdbNeutralO.UseVisualStyleBackColor = True
        '
        'rdbNeturalR
        '
        Me.rdbNeturalR.AutoSize = True
        Me.rdbNeturalR.Location = New System.Drawing.Point(377, 510)
        Me.rdbNeturalR.Name = "rdbNeturalR"
        Me.rdbNeturalR.Size = New System.Drawing.Size(14, 13)
        Me.rdbNeturalR.TabIndex = 50
        Me.rdbNeturalR.TabStop = True
        Me.rdbNeturalR.UseVisualStyleBackColor = True
        '
        'rdbNeutralT
        '
        Me.rdbNeutralT.AutoSize = True
        Me.rdbNeutralT.Location = New System.Drawing.Point(377, 481)
        Me.rdbNeutralT.Name = "rdbNeutralT"
        Me.rdbNeutralT.Size = New System.Drawing.Size(14, 13)
        Me.rdbNeutralT.TabIndex = 51
        Me.rdbNeutralT.TabStop = True
        Me.rdbNeutralT.UseVisualStyleBackColor = True
        '
        'rdbNuetralM
        '
        Me.rdbNuetralM.AutoSize = True
        Me.rdbNuetralM.Location = New System.Drawing.Point(377, 456)
        Me.rdbNuetralM.Name = "rdbNuetralM"
        Me.rdbNuetralM.Size = New System.Drawing.Size(14, 13)
        Me.rdbNuetralM.TabIndex = 52
        Me.rdbNuetralM.TabStop = True
        Me.rdbNuetralM.UseVisualStyleBackColor = True
        '
        'rdbDisagO
        '
        Me.rdbDisagO.AutoSize = True
        Me.rdbDisagO.Location = New System.Drawing.Point(473, 432)
        Me.rdbDisagO.Name = "rdbDisagO"
        Me.rdbDisagO.Size = New System.Drawing.Size(14, 13)
        Me.rdbDisagO.TabIndex = 53
        Me.rdbDisagO.TabStop = True
        Me.rdbDisagO.UseVisualStyleBackColor = True
        '
        'rdbDisagreR
        '
        Me.rdbDisagreR.AutoSize = True
        Me.rdbDisagreR.Location = New System.Drawing.Point(473, 512)
        Me.rdbDisagreR.Name = "rdbDisagreR"
        Me.rdbDisagreR.Size = New System.Drawing.Size(14, 13)
        Me.rdbDisagreR.TabIndex = 54
        Me.rdbDisagreR.TabStop = True
        Me.rdbDisagreR.UseVisualStyleBackColor = True
        '
        'rdbDisagreT
        '
        Me.rdbDisagreT.AutoSize = True
        Me.rdbDisagreT.Location = New System.Drawing.Point(473, 481)
        Me.rdbDisagreT.Name = "rdbDisagreT"
        Me.rdbDisagreT.Size = New System.Drawing.Size(14, 13)
        Me.rdbDisagreT.TabIndex = 55
        Me.rdbDisagreT.TabStop = True
        Me.rdbDisagreT.UseVisualStyleBackColor = True
        '
        'rdbDisagreM
        '
        Me.rdbDisagreM.AutoSize = True
        Me.rdbDisagreM.Location = New System.Drawing.Point(473, 456)
        Me.rdbDisagreM.Name = "rdbDisagreM"
        Me.rdbDisagreM.Size = New System.Drawing.Size(14, 13)
        Me.rdbDisagreM.TabIndex = 56
        Me.rdbDisagreM.TabStop = True
        Me.rdbDisagreM.UseVisualStyleBackColor = True
        '
        'rdbStrongR
        '
        Me.rdbStrongR.AutoSize = True
        Me.rdbStrongR.Location = New System.Drawing.Point(586, 514)
        Me.rdbStrongR.Name = "rdbStrongR"
        Me.rdbStrongR.Size = New System.Drawing.Size(14, 13)
        Me.rdbStrongR.TabIndex = 57
        Me.rdbStrongR.TabStop = True
        Me.rdbStrongR.UseVisualStyleBackColor = True
        '
        'rdbStrongT
        '
        Me.rdbStrongT.AutoSize = True
        Me.rdbStrongT.Location = New System.Drawing.Point(586, 481)
        Me.rdbStrongT.Name = "rdbStrongT"
        Me.rdbStrongT.Size = New System.Drawing.Size(14, 13)
        Me.rdbStrongT.TabIndex = 58
        Me.rdbStrongT.TabStop = True
        Me.rdbStrongT.UseVisualStyleBackColor = True
        '
        'rdbStrongM
        '
        Me.rdbStrongM.AutoSize = True
        Me.rdbStrongM.Location = New System.Drawing.Point(586, 456)
        Me.rdbStrongM.Name = "rdbStrongM"
        Me.rdbStrongM.Size = New System.Drawing.Size(14, 13)
        Me.rdbStrongM.TabIndex = 59
        Me.rdbStrongM.TabStop = True
        Me.rdbStrongM.UseVisualStyleBackColor = True
        '
        'rdbStrongO
        '
        Me.rdbStrongO.AutoSize = True
        Me.rdbStrongO.Location = New System.Drawing.Point(586, 431)
        Me.rdbStrongO.Name = "rdbStrongO"
        Me.rdbStrongO.Size = New System.Drawing.Size(14, 13)
        Me.rdbStrongO.TabIndex = 60
        Me.rdbStrongO.TabStop = True
        Me.rdbStrongO.UseVisualStyleBackColor = True
        '
        'AgreeR
        '
        Me.AgreeR.AutoSize = True
        Me.AgreeR.Location = New System.Drawing.Point(288, 512)
        Me.AgreeR.Name = "AgreeR"
        Me.AgreeR.Size = New System.Drawing.Size(14, 13)
        Me.AgreeR.TabIndex = 61
        Me.AgreeR.TabStop = True
        Me.AgreeR.UseVisualStyleBackColor = True
        '
        'FrmScreen_2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(836, 574)
        Me.Controls.Add(Me.AgreeR)
        Me.Controls.Add(Me.rdbStrongO)
        Me.Controls.Add(Me.rdbStrongM)
        Me.Controls.Add(Me.rdbStrongT)
        Me.Controls.Add(Me.rdbStrongR)
        Me.Controls.Add(Me.rdbDisagreM)
        Me.Controls.Add(Me.rdbDisagreT)
        Me.Controls.Add(Me.rdbDisagreR)
        Me.Controls.Add(Me.rdbDisagO)
        Me.Controls.Add(Me.rdbNuetralM)
        Me.Controls.Add(Me.rdbNeutralT)
        Me.Controls.Add(Me.rdbNeturalR)
        Me.Controls.Add(Me.rdbNeutralO)
        Me.Controls.Add(Me.rdbAgreeT)
        Me.Controls.Add(Me.rdbAgreeM)
        Me.Controls.Add(Me.rdbAgree)
        Me.Controls.Add(Me.rdbRadio)
        Me.Controls.Add(Me.rdbTv)
        Me.Controls.Add(Me.rdbMovies)
        Me.Controls.Add(Me.rdbstrong)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TextBox12)
        Me.Controls.Add(Me.TextBox11)
        Me.Controls.Add(Me.TextBox10)
        Me.Controls.Add(Me.TextBox9)
        Me.Controls.Add(Me.TextBox8)
        Me.Controls.Add(Me.TextBox7)
        Me.Controls.Add(Me.TextBox6)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.lblIndicate)
        Me.Controls.Add(Me.chkoOther)
        Me.Controls.Add(Me.chkBeef)
        Me.Controls.Add(Me.chkChicken)
        Me.Controls.Add(Me.chkPapandWors)
        Me.Controls.Add(Me.chkPasta)
        Me.Controls.Add(Me.chkPizza)
        Me.Controls.Add(Me.lblFavourite)
        Me.Controls.Add(Me.txtAge)
        Me.Controls.Add(Me.txtFirst)
        Me.Controls.Add(Me.txtContact)
        Me.Controls.Add(Me.txtDate)
        Me.Controls.Add(Me.txtSurname)
        Me.Controls.Add(Me.lblAge)
        Me.Controls.Add(Me.lblDate)
        Me.Controls.Add(Me.lblContact)
        Me.Controls.Add(Me.label)
        Me.Controls.Add(Me.lblSuname)
        Me.Controls.Add(Me.lblPersonal)
        Me.Controls.Add(Me.lblTake)
        Me.Name = "FrmScreen_2"
        Me.Text = "Survey"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblTake As System.Windows.Forms.Label
    Friend WithEvents lblPersonal As System.Windows.Forms.Label
    Friend WithEvents lblSuname As System.Windows.Forms.Label
    Friend WithEvents label As System.Windows.Forms.Label
    Friend WithEvents lblContact As System.Windows.Forms.Label
    Friend WithEvents lblDate As System.Windows.Forms.Label
    Friend WithEvents lblAge As System.Windows.Forms.Label
    Friend WithEvents txtSurname As System.Windows.Forms.TextBox
    Friend WithEvents txtDate As System.Windows.Forms.TextBox
    Friend WithEvents txtContact As System.Windows.Forms.TextBox
    Friend WithEvents txtFirst As System.Windows.Forms.TextBox
    Friend WithEvents txtAge As System.Windows.Forms.TextBox
    Friend WithEvents lblFavourite As System.Windows.Forms.Label
    Friend WithEvents chkPizza As System.Windows.Forms.CheckBox
    Friend WithEvents chkPasta As System.Windows.Forms.CheckBox
    Friend WithEvents chkPapandWors As System.Windows.Forms.CheckBox
    Friend WithEvents chkChicken As System.Windows.Forms.CheckBox
    Friend WithEvents chkBeef As System.Windows.Forms.CheckBox
    Friend WithEvents chkoOther As System.Windows.Forms.CheckBox
    Friend WithEvents lblIndicate As System.Windows.Forms.Label
    Friend WithEvents btnSubmit As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents rdbstrong As System.Windows.Forms.RadioButton
    Friend WithEvents rdbMovies As System.Windows.Forms.RadioButton
    Friend WithEvents rdbTv As System.Windows.Forms.RadioButton
    Friend WithEvents rdbRadio As System.Windows.Forms.RadioButton
    Friend WithEvents rdbAgree As System.Windows.Forms.RadioButton
    Friend WithEvents rdbAgreeM As System.Windows.Forms.RadioButton
    Friend WithEvents rdbAgreeT As System.Windows.Forms.RadioButton
    Friend WithEvents rdbNeutralO As System.Windows.Forms.RadioButton
    Friend WithEvents rdbNeturalR As System.Windows.Forms.RadioButton
    Friend WithEvents rdbNeutralT As System.Windows.Forms.RadioButton
    Friend WithEvents rdbNuetralM As System.Windows.Forms.RadioButton
    Friend WithEvents rdbDisagO As System.Windows.Forms.RadioButton
    Friend WithEvents rdbDisagreR As System.Windows.Forms.RadioButton
    Friend WithEvents rdbDisagreT As System.Windows.Forms.RadioButton
    Friend WithEvents rdbDisagreM As System.Windows.Forms.RadioButton
    Friend WithEvents rdbStrongR As System.Windows.Forms.RadioButton
    Friend WithEvents rdbStrongT As System.Windows.Forms.RadioButton
    Friend WithEvents rdbStrongM As System.Windows.Forms.RadioButton
    Friend WithEvents rdbStrongO As System.Windows.Forms.RadioButton
    Friend WithEvents AgreeR As System.Windows.Forms.RadioButton
End Class
