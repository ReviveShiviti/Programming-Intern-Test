﻿Public Class UserDetails
    Private _Surname As String

    Public Property Surname() As String
        Get
            Return _Surname
        End Get
        Set(ByVal value As String)
            _Surname = value

        End Set
    End Property

    Private _firstnames As String

    Public Property firstnames() As String
        Get
            Return _firstnames

        End Get
        Set(ByVal value As String)
            _firstnames = value

        End Set
    End Property

    Private _ContactNumber As String

    Public Property ContactNumber() As String
        Get
            Return _ContactNumber
        End Get
        Set(ByVal value As String)
            _ContactNumber = value

        End Set
    End Property

    Private _Age As String

    Public Property Age As String
        Get
            Return _Age
        End Get
        Set(ByVal value As String)
            _Age = value

        End Set
    End Property

    Public Sub New()
        Surname = ""
        firstnames = ""
        ContactNumber = ""
    End Sub

    Public Sub New(ByVal PSurname As String, ByVal PFirstname As String, ByVal PContactNumber As String)
        Surname = PSurname
        firstnames = PFirstname
        ContactNumber = PContactNumber
    End Sub

    Public Overrides Function ToString() As String
        Return Surname & "," & firstnames & "," & ContactNumber & "," & Age.ToString
    End Function
End Class
