﻿Option Explicit On
Option Strict On

Public Class frmScreen3
    Public Sub ViewData()
        Dim oldest, youngest As Integer

        ListView.Items.Add("TOTAL NUMBER OF SURVEYS  :" & arCnt.ToString)

        oldest = arAge(0)
        For R As Integer = 1 To arCnt - 1
            If arAge(R) > oldest Then
                oldest = arAge(R)

            End If
        Next
        ListView.Items.Add("OLDEST PERSON PARTICIPATED  :" & oldest.ToString)

        youngest = arAge(0)
        For S As Integer = 1 To arCnt - 1
            If arAge(S) < youngest Then
                youngest = arAge(S)

            End If
        Next
        ListView.Items.Add("YOUNGEST PERSON PARTICIPATED  :" & youngest.ToString)
    End Sub

    Public Sub AverageAge()
        Dim sum As Integer = 0
        Dim cnt As Integer
        Dim avg As Double

        For cnt = 0 To arCnt - 1
            sum += arAge(cnt)
        Next

        If arCnt = 0 Then
            avg = 0
        Else
            avg = sum / arCnt
        End If
        ListView.Items.Add("AVERAGE AGE : " & avg.ToString)

    End Sub
    Public Sub FavouriteFood()
        Dim likePizza As Double
        Dim likePasta As Double
        Dim likePapAndWors As Double

        likePizza = (Pizza / arCnt) * 100
        likePasta = (Pasta / arCnt) * 100
        likePapAndWors = (PapWors / arCnt) * 100


        ListView.Items.Add("Percentage of people who like Pizza    " & likePizza.ToString("n2") & "%")
        ListView.Items.Add("Percentage of people who like Pasta    " & likePasta.ToString("n2") & "%")
        ListView.Items.Add("Percentage of people who like Pap and Wors    " & likePapAndWors.ToString("n2") & "%")
    End Sub



    Public Sub CalcRate()
        Dim EatOutRate, WatchMoviess, WatchTvv, Lradioo As Double
        EatOutRate = EatOutRate / arCnt
        WatchMoviess = WatchMovies / arCnt
        WatchTvv = WatchTV / arCnt
        Lradioo = Lradio / arCnt

        ListView.Items.Add("People like to Eat Out:    " & EatOutRate.ToString("n2"))
        ListView.Items.Add("People like to Watch movies:    " & WatchMoviess.ToString("n2"))
        ListView.Items.Add("People like to Watch TV:    " & WatchTvv.ToString("n2"))
        ListView.Items.Add("People like Listen To Radio:    " & Lradioo.ToString("n2"))
    End Sub
    Private Sub frmViewSurvey_Load(sender As Object, e As EventArgs) Handles MyBase.Load


        ListView.Items.Clear()
        Call ViewData()
        Call AverageAge()

        ListView.Items.Add("")
        ListView.Items.Add("----------------------------FAVORATE FOOD---------------------------------------------")

        FavouriteFood()

        ListView.Items.Add("")
        ListView.Items.Add("----------------------------RATES---------------------------------------------")
        CalcRate()

        'lblDate.Text = date
    End Sub



    Private Sub btnOK_Click_1(sender As Object, e As EventArgs) Handles btnOK.Click
        If MessageBox.Show("DO YOU WANT TO EXIT?", "READY TO EXIT!!", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            MessageBox.Show("THANK YOU!:)")
            Application.Exit()
        End If
        Dim btnOk As New Form1
        btnOk.Show()
    End Sub
End Class