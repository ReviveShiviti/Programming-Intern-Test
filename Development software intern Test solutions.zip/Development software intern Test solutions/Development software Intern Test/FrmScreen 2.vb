﻿Public Class FrmScreen_2

 

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
       
        If MessageBox.Show("Do you want to submit?", "READY TO SUBMIT!!", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            Me.Close()
        End If
        Dim btnSub As New Form1
        btnSub.Show()
    End Sub

    
    Private Sub FrmScreen_2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim rdbStrong As Integer
        

        If rdbStrong = True Then

        End If
    End Sub
End Class